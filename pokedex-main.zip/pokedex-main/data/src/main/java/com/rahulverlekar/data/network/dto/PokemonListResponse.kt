package com.rahulverlekar.data.network.dto

data class PokemonNamedResourceDTO(
	val name: String,
	val url: String
)

