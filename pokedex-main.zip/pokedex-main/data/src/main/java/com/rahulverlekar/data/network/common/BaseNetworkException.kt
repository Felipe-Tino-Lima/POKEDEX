package com.rahulverlekar.data.network.common

class BaseNetworkException(localizedMessage: String?) : Exception(localizedMessage) {
}